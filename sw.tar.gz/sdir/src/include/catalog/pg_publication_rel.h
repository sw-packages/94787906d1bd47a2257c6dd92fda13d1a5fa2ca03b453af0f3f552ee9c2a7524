/*-------------------------------------------------------------------------
 *
 * pg_publication_rel.h
 *	  definition of the system catalog for mappings between relations and
 *	  publications (pg_publication_rel)
 *
 * Portions Copyright (c) 1996-2026, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * src/include/catalog/pg_publication_rel.h
 *
 * NOTES
 *	  The Catalog.pm module reads this file and derives schema
 *	  information.
 *
 *-------------------------------------------------------------------------
 */
#ifndef PG_PUBLICATION_REL_H
#define PG_PUBLICATION_REL_H

#include "catalog/genbki.h"
#include "catalog/pg_publication_rel_d.h"	/* IWYU pragma: export */

/* ----------------
 *		pg_publication_rel definition.  cpp turns this into
 *		typedef struct FormData_pg_publication_rel
 * ----------------
 */
BEGIN_CATALOG_STRUCT

CATALOG(pg_publication_rel,6106,PublicationRelRelationId)
{
	Oid			oid;			/* oid */
	Oid			prpubid BKI_LOOKUP(pg_publication); /* Oid of the publication */
	Oid			prrelid BKI_LOOKUP(pg_class);	/* Oid of the relation */
	bool		prexcept BKI_DEFAULT(f);	/* relation is not published */

#ifdef	CATALOG_VARLEN			/* variable-length fields start here */
	pg_node_tree prqual;		/* qualifications */
	int2vector	prattrs;		/* columns to replicate */
#endif
} FormData_pg_publication_rel;

END_CATALOG_STRUCT

/* ----------------
 *		Form_pg_publication_rel corresponds to a pointer to a tuple with
 *		the format of pg_publication_rel relation.
 * ----------------
 */
typedef FormData_pg_publication_rel *Form_pg_publication_rel;

DECLARE_TOAST(pg_publication_rel, 6228, 6229);

DECLARE_UNIQUE_INDEX_PKEY(pg_publication_rel_oid_index, 6112, PublicationRelObjectIndexId, pg_publication_rel, btree(oid oid_ops));
DECLARE_UNIQUE_INDEX(pg_publication_rel_prrelid_prpubid_index, 6113, PublicationRelPrrelidPrpubidIndexId, pg_publication_rel, btree(prrelid oid_ops, prpubid oid_ops));
DECLARE_INDEX(pg_publication_rel_prpubid_index, 6116, PublicationRelPrpubidIndexId, pg_publication_rel, btree(prpubid oid_ops));

MAKE_SYSCACHE(PUBLICATIONREL, pg_publication_rel_oid_index, 64);
MAKE_SYSCACHE(PUBLICATIONRELMAP, pg_publication_rel_prrelid_prpubid_index, 64);

#endif							/* PG_PUBLICATION_REL_H */
